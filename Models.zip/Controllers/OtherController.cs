﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Unison7.Controllers
{
    public class OtherController : Controller
    {
        // GET: Other
        public ActionResult AccessDenied()
        {
            return View();
        }
    }
}