﻿using System.Web.Mvc;

namespace Unison7.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult AnotherLink()
        {
            return View("Index");
        }

        public ActionResult SuggestField()
        {
            return View();
        }
        public ActionResult SuggestField2()
        {
            return View();
        }
    }
}
