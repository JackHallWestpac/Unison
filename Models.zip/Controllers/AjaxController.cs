﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Unison7.Models.HelperMethods;

namespace Unison7.Controllers
{
    public class AjaxController : Controller
    {
        // GET: Ajax
        public ActionResult Index()
        {
            return null;
        }

        // GET: Ajax\GetAgent
        public ActionResult GetAgent(string SalaryID)
        {
            return Json(DataAccess.GetAgent(SalaryID));
        }
    }
}