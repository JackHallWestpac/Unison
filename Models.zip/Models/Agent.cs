﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Unison7.Models
{
    public class Agent
    {
        public string SalaryID { get; set; }
        public string STGID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string FullInfo
        {
            get
            {
                return $" { SalaryID } { STGID } { FirstName } { LastName }";
            }
        }
    }
}