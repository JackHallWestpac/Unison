﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Web;

namespace Unison7.Models.HelperMethods
{
    public class ConfigurationSettings
    {
        public static string GetDatabaseConnectionString(string name)
        {
            string connStr = ConfigurationManager.ConnectionStrings[name].ConnectionString;
            return connStr;
        }
    }
}