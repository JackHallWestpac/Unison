﻿using Dapper;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace Unison7.Models.HelperMethods
{
    public class DataAccess
    {
        public static List<Agent> GetAgent(string SalaryID)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(ConfigurationSettings.GetDatabaseConnectionString("Unison")))
            {
                return connection.Query<Agent>("dbo.GetAgent @SalaryID", new { SalaryID = SalaryID }).ToList();
            }
        }

        internal void InsertAgent(string AgentID, string STGID, string FirstName, string LastName)
        {
            using (IDbConnection connection = new System.Data.SqlClient.SqlConnection(ConfigurationSettings.GetDatabaseConnectionString("Unison")))
            {
                List<Agent> Agents = new List<Agent>();

                Agents.Add(new Agent { SalaryID = AgentID, STGID = STGID, FirstName = FirstName, LastName = LastName });

                connection.Execute("dbo.CreateAgent @SalaryID, @STGID, @FirstName, @LastName", Agents);
            }
        }
    }
}